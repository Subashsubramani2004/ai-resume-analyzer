import { Link } from "react-router-dom";

function Landing() {
  return (
    <div className="page">
      <header className="landing-nav">
        <div className="brand">ResumeAI</div>
        <nav className="nav-center">
          <a href="#top">Home</a>
          <a href="#features">Features</a>
          <a href="#how-it-works">How It Works</a>
        </nav>
        <div className="nav-right">
          <Link to="/login" className="btn btn-ghost">Login</Link>
          <Link to="/register" className="btn btn-gradient">Get Started</Link>
        </div>
      </header>

      <section className="hero-split" id="top">
        <div>
          <span className="hero-eyebrow">✦ AI-Powered Resume Analysis</span>
          <h1>Land Your Dream Job with AI-Powered Resume Analysis.</h1>
          <p className="lede">
            Optimize your resume for ATS systems, identify skill gaps, and get actionable
            AI suggestions in seconds.
          </p>
          <div className="hero-actions">
            <Link to="/register" className="btn btn-gradient">Analyze My Resume →</Link>
            <a href="#how-it-works" className="btn btn-ghost">See How It Works</a>
          </div>
          <p className="hero-proof">10,000+ job seekers improved their hireability</p>
        </div>

        <div className="hero-mock">
          <div className="hero-mock-badge">
            <span className="dot"></span> ATS Score: Excellent
          </div>
          <div className="hero-mock-line tall"></div>
          <div className="hero-mock-line"></div>
          <div className="hero-mock-line"></div>
          <div className="hero-mock-line short"></div>
        </div>
      </section>

      <section className="section" id="features">
        <h2>Why choose ResumeAI?</h2>
        <p className="section-sub">
          Our advanced algorithms analyze your resume from an employer's perspective,
          giving you the edge in a competitive market.
        </p>

        <div className="feature-grid">
          <div className="feature-card">
            <div className="feature-icon">◆</div>
            <h3>ATS Optimization</h3>
            <p>Beat the bots with precise keyword matching. We compare your resume against real job descriptions to ensure you pass the initial screen.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">◎</div>
            <h3>Skill Gap Analysis</h3>
            <p>Discover exactly what's missing for your target role. Our AI identifies crucial skills required in your industry that aren't on your resume.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">✎</div>
            <h3>Smart Suggestions</h3>
            <p>Get personalized rewrites to boost your impact. Turn passive statements into powerful, action-oriented bullet points that stand out.</p>
          </div>
        </div>
      </section>

      <section className="cta-banner" id="how-it-works">
        <h2>Ready to start?</h2>
        <p>Join thousands of successful candidates who used ResumeAI to land their next big opportunity. It takes less than 2 minutes.</p>
        <Link to="/register" className="btn btn-gradient">Get Started for Free →</Link>
      </section>

      <footer className="site-footer">
        <p>ResumeAI — FastAPI, React &amp; Gemini.</p>
      </footer>
    </div>
  );
}

export default Landing;